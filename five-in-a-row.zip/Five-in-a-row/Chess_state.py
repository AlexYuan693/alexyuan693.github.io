class chess():
    def __init__(self,color,column,row):
        self.color=color
        self.column=column
        self.row=row
